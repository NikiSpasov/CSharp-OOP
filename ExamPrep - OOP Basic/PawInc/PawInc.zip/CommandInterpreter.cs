﻿public class CommandInterpreter
{
    public void interpret(string[] args)
    {
        string command = args[0];

        switch (command)
        {
            case "RegisterCleansingCenter":
                break;
            case "RegisterAdoptionCenter":
                break;
            case "RegisterDog":
                break;
            case "RegisterCat":
                break;
            case "SendForCleansing":
                break;
            case "Cleanse":
                break;
            case "Adopt":
                break;
        }
    }
}

