﻿public interface ICreature
{
    string Id { get; }
    string Type { get; }
}

