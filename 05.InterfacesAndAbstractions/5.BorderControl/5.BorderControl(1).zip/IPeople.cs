﻿using System.Collections.Generic;

public interface IPeople
{
    string Id { get; }
}

