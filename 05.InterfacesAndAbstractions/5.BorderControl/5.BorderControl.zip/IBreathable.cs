﻿public interface IBreathable : ICreature
{
    string Birthdate { get; }
    string Name { get; }
}

