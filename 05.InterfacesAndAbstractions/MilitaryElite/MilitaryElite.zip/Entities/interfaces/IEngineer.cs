﻿using System.Collections.Generic;

public interface IEngineer
    {
        IDictionary<string, int> Repairs { get; }
    }

