﻿public interface ISoldier
{
    string FirstName { get; }
    string LastName { get; }
    int Id { get; }
}

