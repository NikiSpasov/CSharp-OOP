﻿public interface ISpy
    {
        int CodeNumber { get;  }
    }

