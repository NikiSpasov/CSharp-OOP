﻿using System;
using System.Collections.Generic;

public class Frog
{
    private Lake frogLake;

    public Frog(Lake lake)
    {
        frogLake = lake;
    }
    
}

