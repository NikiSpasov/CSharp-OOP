﻿using System;

public class StartUp
{
    public static void Main()
    {
        CardGame cardGame = new CardGame();
        cardGame.StartGame();
    }
}

