﻿
[Type("Enumeration", "Suit", "Provides suit constants for a Card class.")]
public enum Suit
{
    Clubs,
    Hearts,
    Diamonds,
    Spades
}

