﻿
using System;

public class StartUp
{
    public static void Main()
    {
        CardGenerator cardGenerator = new CardGenerator();
        //var input = Console.ReadLine();
        //if (input == "Card Deck")
        //{
            cardGenerator.Run();
        //}
    }
}