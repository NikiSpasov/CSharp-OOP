﻿public enum CardSuits
{
    Clubs,
    Diamonds,
    Hearts,
    Spades
}

