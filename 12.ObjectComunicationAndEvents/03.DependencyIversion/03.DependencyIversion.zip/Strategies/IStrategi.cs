﻿  public interface IStrategi
  {
      int Calculate(int first, int second);
  }

