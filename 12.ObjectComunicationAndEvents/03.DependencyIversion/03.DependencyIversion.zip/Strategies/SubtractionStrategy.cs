﻿
public class SubtractionStrategy : IStrategi
{
    public int Calculate(int firstOperand, int secondOperand)
    {
        return firstOperand - secondOperand;
    }
}
