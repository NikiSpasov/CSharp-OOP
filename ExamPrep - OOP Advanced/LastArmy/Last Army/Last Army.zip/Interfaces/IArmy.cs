﻿using System.Collections.Generic;

public interface IArmy
{
    IReadOnlyList<Soldier> Soldiers { get; }

    void AddSoldier(ISoldier soldier);

    void RegenerateTeam(string soldierType);
}