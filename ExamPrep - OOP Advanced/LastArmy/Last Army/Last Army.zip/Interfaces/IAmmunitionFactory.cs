﻿public interface IAmmunitionFactory
{
    IAmmunition CreateAmmunition(string ammunitionName);
}