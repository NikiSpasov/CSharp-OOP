﻿public static class OutputMessages
{
    public static string MissionSuccessful = "Mission completed - ";
    public static string MissionOnHold = "Mission on hold - ";
    public static string MissionDeclined = "Mission declined - ";

}

