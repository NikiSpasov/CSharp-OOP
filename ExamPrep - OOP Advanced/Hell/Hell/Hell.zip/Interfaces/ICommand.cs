﻿public interface ICommand
{
    string Execute();
}

