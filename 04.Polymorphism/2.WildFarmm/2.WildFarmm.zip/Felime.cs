﻿

public abstract class Felime : Mammal
{
    protected Felime(string animalType, string animalName, double animalWieght, string region)
        : base(animalType, animalName, animalWieght, region)
    {
    }
}
