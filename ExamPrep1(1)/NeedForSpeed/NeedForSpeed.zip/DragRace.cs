﻿
using System.Collections.Generic;

public class DragRace : Race
{
    public DragRace(int length, string route, int prizePool, List<Car> participants) 
        : base(length, route, prizePool, participants)
    {

    }
}

