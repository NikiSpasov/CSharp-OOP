﻿using System.Collections.Generic;

public class DriftRace : Race
{
    public DriftRace(int length, string route, int prizePool, List<Car> participants) : base(length, route, prizePool, participants)
    {
    }
}

